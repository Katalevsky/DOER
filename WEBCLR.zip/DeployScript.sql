/*
alter database report_contour set trustworthy on;

create assembly [Web] 
authorization [dbo] 
from 'D:\CLR\Web.dll' 
with permission_set = EXTERNAL_ACCESS;

create procedure [dbo].[web_datafile]
	 @url		nvarchar(4000)
	,@metadata	nvarchar(4000)
	,@split		nvarchar(4000)
as external NAME [Web].[StoredProcedures].[GetFileData];
*/

create table #buffer
(
	 date	varchar(max)
	,time	varchar(max)	
	,high	varchar(max)
	,low	varchar(max)
)

exec dbo.web_datafile
	 @url = 'http://195.128.78.52/temp.csv?market=5&em=83&code=EURUSD&apply=0&df=1&mf=0&yf=2012&from=01.01.2012&dt=31&mt=0&yt=2012&to=31.01.2012&p=2&f=EURUSD_120101_120131&e=.csv&cn=EURUSD&dtf=1&tmf=3&MSOR=1&mstime=on&mstimever=1&sep=3&sep2=1&datf=5'
	,@metadata = 'date:0;time:1;high:3;low:4'
	,@split = ';'
